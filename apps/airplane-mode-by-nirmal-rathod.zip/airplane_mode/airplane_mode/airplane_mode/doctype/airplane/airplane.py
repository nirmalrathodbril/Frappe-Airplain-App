# Copyright (c) 2024, Nirmal Rathod and contributors
# For license information, please see license.txt

# import frappe
from frappe.model.document import Document


class Airplane(Document):
	pass
