# import frappe
# no_cache = 1
# def get_context(context):
# 	color = frappe.form_dict.get('color', 'black')
# 	context.color = color or 'black'
